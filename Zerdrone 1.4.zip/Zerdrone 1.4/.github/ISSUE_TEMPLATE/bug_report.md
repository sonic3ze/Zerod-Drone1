---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: kurpingspace2

---

**What happened?**
The bot did not do this:

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**What did you expect to happen?**
___ Should have done this

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Additional context**
Add any other context about the problem here.
